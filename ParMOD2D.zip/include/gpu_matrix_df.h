#ifndef GPU_MATRIX_DF
#define GPU_MATRIX_DF
/*
int POS_B;
int POS_M;
int POS_F;
int POS_D;

int diffusion;
int advection;
float lambda;
float mob;
float decay;
float Vx;
float Vy;
*/

__device__ void diff_node(int def_med, int velocity_vec, float *lambda, float *DF, int loc_val, int POS_DF1, int POS_DF2, float *V, float mob, float *dh, int diffusion, int advection, float *FD_1, float *FD_2, int cadv){

	if ((diffusion == 1) && (advection == 0)){
		if (def_med == 0){
			FD_1[loc_val] = -lambda[0] * (DF[0] / (dh[0] * dh[0]));
			FD_2[loc_val] = lambda[0] * (DF[0] / (dh[0] * dh[0]));
		}
		else if (def_med == 1){
			FD_1[loc_val] = -lambda[POS_DF1] * ((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0];
			FD_2[loc_val] = lambda[POS_DF1] * ((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0];
		}
		else if (def_med == 2){
			FD_1[loc_val] = -lambda[POS_DF1] * ((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0];
			FD_2[loc_val] = lambda[POS_DF1] * ((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0];
		}
		else if (def_med == 3){
			FD_1[loc_val] = -lambda[POS_DF1] * (sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0];
			FD_2[loc_val] = lambda[POS_DF1] * (sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0];
		}
	}

	if (velocity_vec == 1){
		if ((advection == 1) && (diffusion == 0)){
			if (def_med == 0){
				FD_1[loc_val] = -lambda[0] * (cadv*V[POS_DF2] * mob / (2 * dh[0]));
				FD_2[loc_val] = lambda[0] * (cadv*V[POS_DF2] * mob / (2 * dh[0]));
			}
			else{
				FD_1[loc_val] = -lambda[POS_DF1] * (cadv*V[POS_DF2] * mob / (2 * dh[0]));
				FD_2[loc_val] = lambda[POS_DF1] * (cadv*V[POS_DF2] * mob / (2 * dh[0]));
			}
		}

		if ((diffusion == 1) && (advection == 1)){
			if (def_med == 0){
				FD_1[loc_val] = -lambda[0] * (DF[0] / (dh[0] * dh[0]) + (cadv*V[POS_DF2] * mob / (2 * dh[0])));
				FD_2[loc_val] = lambda[0] * (DF[0] / (dh[0] * dh[0]) + (cadv*V[POS_DF2] * mob / (2 * dh[0])));
			}
			else if (def_med == 1){
				FD_1[loc_val] = -lambda[POS_DF1] * ((((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0]) + (cadv*V[POS_DF2] * mob / (2 * dh[0])));
				FD_2[loc_val] = lambda[POS_DF1] * ((((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0]) + (cadv*V[POS_DF2] * mob / (2 * dh[0])));
			}
			else if (def_med == 2){
				FD_1[loc_val] = -lambda[POS_DF1] * ((((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0]) + (cadv*V[POS_DF2] * mob / (2 * dh[0])));
				FD_2[loc_val] = lambda[POS_DF1] * ((((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0]) + (cadv*V[POS_DF2] * mob / (2 * dh[0])));
			}
			else if (def_med == 3){
				FD_1[loc_val] = -lambda[POS_DF1] * (((sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0]) + (cadv*V[POS_DF2] * mob / (2 * dh[0])));
				FD_2[loc_val] = lambda[POS_DF1] * (((sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0]) + (cadv*V[POS_DF2] * mob / (2 * dh[0])));
			}
		}
	}

	else{

		if ((advection == 1) && (diffusion == 0)){
			if (def_med == 0){
				FD_1[loc_val] = -lambda[0] * (cadv*V[0] * mob / (2 * dh[0]));
				FD_2[loc_val] = lambda[0] * (cadv*V[0] * mob / (2 * dh[0]));
			}
			else{
				FD_1[loc_val] = -lambda[POS_DF1] * (cadv*V[0] * mob / (2 * dh[0]));
				FD_2[loc_val] = lambda[POS_DF1] * (cadv*V[0] * mob / (2 * dh[0]));
			}
		}

		if ((diffusion == 1) && (advection == 1)){
			if (def_med == 0){
				FD_1[loc_val] = -lambda[0] * (DF[0] / (dh[0] * dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
				FD_2[loc_val] = lambda[0] * (DF[0] / (dh[0] * dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
			}
			else if (def_med == 1){
				FD_1[loc_val] = -lambda[POS_DF1] * ((((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
				FD_2[loc_val] = lambda[POS_DF1] * ((((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
			}
			else if (def_med == 2){
				FD_1[loc_val] = -lambda[POS_DF1] * ((((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
				FD_2[loc_val] = lambda[POS_DF1] * ((((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
			}
			else if (def_med == 3){
				FD_1[loc_val] = -lambda[POS_DF1] * (((sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
				FD_2[loc_val] = lambda[POS_DF1] * (((sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
			}
		}

	}
	

}

__device__ void center(int def_med, float *lambda, float *FD_1, float *FD_2, int loc_val, int POS_B, int POS_M, int POS_F, int POS_D, float decay, float dt){
	if (def_med != 0) {
		FD_1[loc_val] = (1 / dt) - (FD_1[POS_B] + FD_1[POS_M] + FD_1[POS_F] + FD_1[POS_D] - lambda[POS_B] * decay);//E1[0];
		FD_2[loc_val] = (1 / dt) - (FD_2[POS_B] + FD_2[POS_M] + FD_2[POS_F] + FD_2[POS_D] + lambda[POS_B] * decay);//E2[0];
	}
	else{
		FD_1[loc_val] = (1 / dt) - (FD_1[POS_B] + FD_1[POS_M] + FD_1[POS_F] + FD_1[POS_D] - lambda[0] * decay);//E1[0];
		FD_2[loc_val] = (1 / dt) - (FD_2[POS_B] + FD_2[POS_M] + FD_2[POS_F] + FD_2[POS_D] + lambda[0] * decay);//E2[0];
	}
}

/*
__global__ void gerMatLoc(float *U0, int *CT, int *River, int *Pos, int N, int cols, int rows){

	int mov = blockDim.x*blockIdx.x + threadIdx.x;

	while (mov < N){

		if (U0[mov] <= 0){
			U0[mov] = nan("nan");
			River[mov] = nan("nan");
		}

		if ((U0[mov] > 0) || (isnan(U0[mov]) != 1)){

			CT[mov] = 1;
			River[mov] = 1;
			Pos[mov] = mov;

		}

		mov += gridDim.x * blockDim.x;

	}

}
*/


__global__ void ClassMatPOS(int def_med, int velocity_vec, int diffusion, int advection, float *lambda, float decay, float mob, int *CT, int *Loc, \
	int *IDrow, int *IDcolumn, float *FD_1, float *FD_2, int cols, int rows, int N, \
	int Nval, float *DFx, float *DFy, float *Vx, float *Vy, float *dx, float *dy, float dt){
	
	//Nval � o n�mero de elementos ativos

	int mov = blockDim.x*blockIdx.x + threadIdx.x;

	while (mov < N){
		int x = mov % cols;
		int y = mov / cols;
		if (CT[mov] != 0){
			// TOP
			if (y > 0){
				if (CT[mov - cols] == 0){
					// encontrar posi��o do primeiro n� n�o nulo acima 
					//int re = 0;
				    //int reCT = 0;
					//int an = 0; /*0*/
					//int a = 0;
					//while ((reCT == 0) && (a == 0)){
						//an++;
						//if ((mov - an*cols) / cols > 0){/*>*/
							//re = Loc[mov - an*cols];
							//reCT = CT[mov - an*cols];
						//}
						//else{ a = 1; }
					//}
					//if (reCT != 0){
						//IDcolumn[Loc[mov]] = re;
						//IDrow[Loc[mov]] = Loc[mov];
						//diff_node(def_med,velocity_vec, lambda, DFy, Loc[mov], Loc[mov], re, Vy, mob, dy, diffusion, advection, FD_1, FD_2,-1);
					//}
					//else{
						IDcolumn[Loc[mov]] = -1;
						IDrow[Loc[mov]] = Loc[mov];
					//}
				}
				else{
					IDcolumn[Loc[mov]] =  Loc[mov - cols];
					IDrow[Loc[mov]] = Loc[mov];
		
					diff_node(def_med,velocity_vec, lambda, DFy, Loc[mov], Loc[mov], Loc[mov - cols], Vy, mob, dy, diffusion, advection, FD_1, FD_2, -1); //-Vy
				}
			}

			// BOTTOM
			//__syncthreads();
			if (y < rows - 1){
				if (CT[mov + cols] == 0){
					//int re1 = 0;
					//int reCT1 = 0;
					//int an1 = 0;
					//int a1 = 0;
					//while ((reCT1 == 0) && (a1 == 0)){
						//an1++;
						//if ((mov + an1*cols) / cols < rows - 1){/*<*/
							//re1 = Loc[mov + an1*cols];
							//reCT1 = CT[mov + an1*cols];
						//}
						//else{ a1 = 1; }
					//}
					//if (reCT1 != 0){
						//IDcolumn[Loc[mov] + Nval] = re1;
						//IDrow[Loc[mov] + Nval] = Loc[mov];
					    //diff_node(def_med,velocity_vec, lambda, DFy, Loc[mov] + Nval, Loc[mov], re1, Vy, mob, dy, diffusion, advection, FD_1, FD_2,1);
					//}
					//else{
						IDcolumn[Loc[mov] + Nval] = -1;
						IDrow[Loc[mov] + Nval] = Loc[mov];
					//}
				}
				else{
					IDcolumn[Loc[mov] + Nval] = Loc[mov + cols];
					IDrow[Loc[mov] + Nval] = Loc[mov];
					diff_node(def_med, velocity_vec, lambda, DFy, Loc[mov] + Nval, Loc[mov], Loc[mov + cols], Vy, mob, dy, diffusion, advection, FD_1, FD_2, 1);
				}
			}

			//RIGHT
			//__syncthreads();
			if (x < cols - 1){
				if (CT[mov + 1] == 0){
					//int re2 = 0;
					//int reCT2 = 0;
					//int an2 = 0;
					//int a2 = 0;
					//while ((reCT2 == 0) && (a2 == 0)){
						//an2++;
						//if ((mov + an2) % cols < cols - 1){/*<*/
							//re2 = Loc[mov + an2];
							//reCT2 = CT[mov + an2];
						//}
						//else{ a2 = 1; }
					//}
					//if (reCT2 != 0){
						//IDcolumn[Loc[mov] + 2 * Nval] = Loc[mov] + 1;
						//IDrow[Loc[mov] + 2 * Nval] = Loc[mov];
						//diff_node(def_med,velocity_vec, lambda, DFx, Loc[mov] + 2 * Nval, Loc[mov], Loc[mov] + 1, Vx, mob, dx, diffusion, advection, FD_1, FD_2,-1);
					//}
					//else{
						IDcolumn[Loc[mov] + 2 * Nval] = -1;
						IDrow[Loc[mov] + 2 * Nval] = Loc[mov];
					//}
				}
				else{
					IDcolumn[Loc[mov] + 2 * Nval] = Loc[mov] + 1;
					IDrow[Loc[mov] + 2 * Nval] = Loc[mov];				
					diff_node(def_med, velocity_vec, lambda, DFx, Loc[mov] + 2 * Nval, Loc[mov], Loc[mov] + 1, Vx, mob, dx, diffusion, advection, FD_1, FD_2, -1);
				}
			}

			// LEFT 
			//__syncthreads();
			if (x > 0){

				if (CT[mov - 1] == 0){
					//int re3 = 0;
					//int reCT3 = 0;
					//int an3 = 0;
					//int a3 = 0;
					//while ((reCT3 == 0) && (a3 == 0)){
						//an3++;
						//if ((mov - an3) % cols > 0){/*>=*/
							//re3 = Loc[mov - an3];
							//reCT3 = CT[mov - an3];
						//}
						//else{ a3 = 1; }
					//}

					//if (reCT3 != 0){
						//IDcolumn[Loc[mov] + 3 * Nval] = Loc[mov] - 1;
						//IDrow[Loc[mov] + 3 * Nval] = Loc[mov];
						//diff_node(def_med,velocity_vec, lambda, DFx, Loc[mov] + 3 * Nval, Loc[mov], Loc[mov] - 1, Vx, mob, dx, diffusion, advection, FD_1, FD_2,1);
					//}
					//else{
						IDcolumn[Loc[mov] + 3 * Nval] = -1;
						IDrow[Loc[mov] + 3 * Nval] = Loc[mov];
					//}
				}
				else{
					IDcolumn[Loc[mov] + 3 * Nval] = Loc[mov] - 1;
					IDrow[Loc[mov] + 3 * Nval] = Loc[mov];
					diff_node(def_med, velocity_vec, lambda, DFx, Loc[mov] + 3 * Nval, Loc[mov], Loc[mov] - 1, Vx, mob, dx, diffusion, advection, FD_1, FD_2, 1);					
				}
			}
		
			//__syncthreads();
			
			//========================= Diagonais Internas =====================
			if ((IDcolumn[Loc[mov] + 2 * Nval] == -1) && (IDcolumn[Loc[mov] + 3 * Nval] != -1)){
				FD_1[Loc[mov] + 3 * Nval] =  2 * FD_1[Loc[mov] + 3 * Nval]; //D
				FD_2[Loc[mov] + 3 * Nval] =  2 * FD_2[Loc[mov] + 3 * Nval]; //D
			}
			if ((IDcolumn[Loc[mov] + 2 * Nval] != -1) && (IDcolumn[Loc[mov] + 3 * Nval] == -1)){
				FD_1[Loc[mov] + 2 * Nval] =  2 * FD_1[Loc[mov] + 2 * Nval]; //F
				FD_2[Loc[mov] + 2 * Nval] =  2 * FD_2[Loc[mov] + 2 * Nval]; //F
			}

			//========================= Diagonais Externas ====================
			if ((IDcolumn[Loc[mov]] == -1) && (IDcolumn[Loc[mov] + Nval] != -1)){
				FD_1[Loc[mov] + Nval] =  2 * FD_1[Loc[mov] + Nval]; //M
				FD_2[Loc[mov] + Nval] =  2 * FD_2[Loc[mov] + Nval]; //M
			}
			if ((IDcolumn[Loc[mov]] != -1) && (IDcolumn[Loc[mov] + Nval] == -1)){
				FD_1[Loc[mov]] =  2 * FD_1[Loc[mov]]; //B
				FD_2[Loc[mov]] =  2 * FD_2[Loc[mov]]; //B
			}
			//==================================================================
			//========================  Diagonal Principal =====================
			

			IDrow[Loc[mov] + 4 * Nval] = Loc[mov];
			IDcolumn[Loc[mov] + 4 * Nval] = Loc[mov];
			
			center(def_med,lambda, FD_1, FD_2, Loc[mov] + 4 * Nval, Loc[mov], Loc[mov] + Nval, Loc[mov] + 2 * Nval, Loc[mov] + 3 * Nval, decay, dt);

			/*
			if ((IDcolumn[Loc[mov] + 2 * Nval] == -1) && (IDcolumn[Loc[mov] + 3 * Nval] == -1)){
				FD_1[Loc[mov] + 4 * Nval] = FD_1[Loc[mov] + 4 * Nval] - (FD_1[Loc[mov] + 3 * Nval] + FD_1[Loc[mov] + 2 * Nval]);
				FD_2[Loc[mov] + 4 * Nval] = FD_2[Loc[mov] + 4 * Nval] - (FD_2[Loc[mov] + 3 * Nval] + FD_2[Loc[mov] + 2 * Nval]);				
			}

			if ((IDcolumn[Loc[mov]] == -1) && (IDcolumn[Loc[mov] + Nval] == -1)){
				FD_1[Loc[mov] + 4 * Nval] = FD_1[Loc[mov] + 4 * Nval] - (FD_1[Loc[mov]] + FD_1[Loc[mov] + Nval]);
				FD_2[Loc[mov] + 4 * Nval] = FD_2[Loc[mov] + 4 * Nval] - (FD_2[Loc[mov]] + FD_2[Loc[mov] + Nval]);				
			}
			
			
			//======			
			if ((IDcolumn[Loc[mov] + 2 * Nval] == -1) && (IDcolumn[Loc[mov] + 3 * Nval] == -1) && (IDcolumn[Loc[mov]] == -1)){			
				FD_1[Loc[mov] + 4 * Nval] = FD_1[Loc[mov] + 4 * Nval] - (FD_1[Loc[mov] + 3 * Nval] + FD_1[Loc[mov] + 2 * Nval] + FD_1[Loc[mov]]);
				FD_2[Loc[mov] + 4 * Nval] = FD_2[Loc[mov] + 4 * Nval] - (FD_2[Loc[mov] + 3 * Nval] + FD_2[Loc[mov] + 2 * Nval] + FD_2[Loc[mov]]);			
			}

			if ((IDcolumn[Loc[mov] + 2 * Nval] == -1) && (IDcolumn[Loc[mov] + 3 * Nval] == -1) && (IDcolumn[Loc[mov] + Nval] == -1)){
				FD_1[Loc[mov] + 4 * Nval] = FD_1[Loc[mov] + 4 * Nval] - (FD_1[Loc[mov] + 3 * Nval] + FD_1[Loc[mov] + 2 * Nval] + FD_1[Loc[mov] + Nval]);
				FD_2[Loc[mov] + 4 * Nval] = FD_2[Loc[mov] + 4 * Nval] - (FD_2[Loc[mov] + 3 * Nval] + FD_2[Loc[mov] + 2 * Nval] + FD_2[Loc[mov] + Nval]);
			}

			if ((IDcolumn[Loc[mov]] == -1) && (IDcolumn[Loc[mov] + Nval] == -1) && (IDcolumn[Loc[mov] + 2 * Nval] == -1)){			
				FD_1[Loc[mov] + 4 * Nval] = FD_1[Loc[mov] + 4 * Nval] - (FD_1[Loc[mov]] + FD_1[Loc[mov] + Nval] + FD_1[Loc[mov] + 2 * Nval]);
				FD_2[Loc[mov] + 4 * Nval] = FD_2[Loc[mov] + 4 * Nval] - (FD_2[Loc[mov]] + FD_2[Loc[mov] + Nval] + FD_2[Loc[mov] + 2 * Nval]);
			}

			if ((IDcolumn[Loc[mov]] == -1) && (IDcolumn[Loc[mov] + Nval] == -1) && (IDcolumn[Loc[mov] + 3 * Nval] == -1)){
				FD_1[Loc[mov] + 4 * Nval] = FD_1[Loc[mov] + 4 * Nval] - (FD_1[Loc[mov]] + FD_1[Loc[mov] + Nval] + FD_1[Loc[mov] + 3 * Nval]);
				FD_2[Loc[mov] + 4 * Nval] = FD_2[Loc[mov] + 4 * Nval] - (FD_2[Loc[mov]] + FD_2[Loc[mov] + Nval] + FD_2[Loc[mov] + 3 * Nval]);
			}			
			//==================================================================
			*/

		}
		mov += gridDim.x * blockDim.x;
	}
}

#endif