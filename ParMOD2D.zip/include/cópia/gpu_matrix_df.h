#ifndef GPU_MATRIX_DF
#define GPU_MATRIX_DF

//Termo difusivo para condi��es homog�neas
__device__ void diffusion1(float *DF,float *dh, float *TDF){
	
	//Termo difusivo para condi��es homog�neas 

	// Entradas:
	// DF1 � o coeficiente de difus�o
	// dh � o espa�amento da malha no ponto
	//Sa�das:
	//TDF � o valor para o termo difusivo no ponto

	TDF[0] = DF[0] /(dh[0] * dh[0]);

}
//Termo difusivo para condi��es heterog�neas
__device__ void diffusion2(int def_med, float *DF,int POS_DF1, int POS_DF2, float *dh, float *TDF){
	
	// Termo difusivo para condi��es Heterog�neas e anisotr�picas

	// Entradas:
	// def_med define qual tipo de m�dia ser� usada para c�lcular o coeficiente de difus�o:
	//    0 - Condi��o de homogeneidade
	//    1 - m�dia aritm�tica
	//    2 - m�dia harm�nica
	//    3 - m�dia geom�trica

	// DF � o coeficiente de difus�o
	// dh � o espa�amento da malha

	//Sa�das:
	//TDF � o valor m�dio para o termo difusivo no ponto

	if (def_med == 1) {
		TDF[0] = ((DF[POS_DF1]*dh[0] + DF[POS_DF2]*dh[0])/(2*dh[0]*dh[0]))/dh[0];
	}
	else if (def_med == 2){
		TDF[0] = ((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0];
		//D[offset] = ((2 * Tx[offset] * Tx[left]) / (Tx[offset] * dx[ix - 1] + Tx[left] * dx[ix])) / dx[ix];
		//M[offset] = ((2 * Ty[offset] * Ty[bottom]) / (Ty[offset] * dy[iy + 1] + Ty[bottom] * dy[iy])) / dy[iy];
		//F[offset] = ((2 * Tx[offset] * Tx[right]) / (Tx[offset] * dx[ix + 1] + Tx[right] * dx[ix])) / dx[ix];
	}
	else if (def_med == 3){
		TDF[0] = (sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0];
	}
}
//Termo advectivo
__device__ void advection1(float mob, float V, float *dh, float *TADV){
	//Termo advectivo para condi��es homog�neas
	//Entradas:
	// mob � a mobilidade 
	// V � a componente da velocidade
	// dh1 � o espa�amento no ponto
    //Sa�da:
	//TADV � o termo advectivo

	TADV[0] = V*mob / (2 * dh[0]);

}



__device__ void top(int def_med, float lambda, float *DF, int POS_DF1, int POS_DF2, float V, float mob, float *dh, int diffusion, int advection, float *TDF, float *TADV, float *B){
	
	if (diffusion == 1){
		if (def_med == 0){
			diffusion1(DF, dh, TDF);
		}
		else{
			diffusion2(def_med, DF,POS_DF1,POS_DF2, dh, TDF);
		}
	}

	if (advection == 1){
		advection1(mob, V, dh, TADV);
	}

	B[0] = lambda*(TDF[0] + TADV[0]);

}

__device__ void bottom(int def_med, float lambda, float *DF, int POS_DF1, int POS_DF2, float V, float mob, float *dh, int diffusion, int advection, float *TDF, float *TADV, float *M){

	if (diffusion == 1){
		if (def_med == 0){
			diffusion1(DF, dh, TDF);
		}
		else{
			diffusion2(def_med, DF, POS_DF1, POS_DF2, dh, TDF);
		}
	}

	if (advection == 1){
		advection1(mob, V, dh, TADV);
	}

	M[0] = lambda*(TDF[0] - TADV[0]);

}

__device__ void right(int def_med, float lambda, float *DF, int POS_DF1, int POS_DF2, float V, float mob, float *dh, int diffusion, int advection, float *TDF, float *TADV, float *F){


	if (diffusion == 1){
		if (def_med == 0){
			diffusion1(DF, dh, TDF);
		}
		else{
			diffusion2(def_med, DF, POS_DF1, POS_DF2, dh, TDF);
		}
	}

	if (advection == 1){
		advection1(mob, V, dh, TADV);
	}

	F[0] = lambda*(TDF[0] - TADV[0]);

}

__device__ void left(int def_med, float lambda, float *DF, int POS_DF1, int POS_DF2, float V, float mob, float *dh, int diffusion, int advection, float *TDF, float *TADV, float *D){

	if (diffusion == 1){
		if (def_med == 0){
			diffusion1(DF, dh, TDF);
		}
		else{
			diffusion2(def_med, DF, POS_DF1, POS_DF2, dh, TDF);
		}
	}

	if (advection == 1){
		advection1(mob, V, dh, TADV);
	}

	D[0] = lambda*(TDF[0] + TADV[0]);

}


__device__ void center1(float lambda, float *DIAG,int POS_B, int POS_M,int POS_F, int POS_D, float decay,float dt, float *E1){

	E1[0] = (1/dt) + (DIAG[POS_B] + DIAG[POS_M] + DIAG[POS_F] + DIAG[POS_D] + lambda*decay);
}

__device__ void center2(float lambda, float *DIAG, int POS_B, int POS_M, int POS_F, int POS_D, float decay,float dt, float *E2){
	E2[0] = (1/dt) - (DIAG[POS_B] + DIAG[POS_M] + DIAG[POS_F] + DIAG[POS_D] + lambda*decay);
}


// KERNELS

__global__ void gerMatLoc(float *U0, int *CT, int *River, int *Pos, int N, int DIMx, int DIMy){

	int mov = blockDim.x*blockIdx.x + threadIdx.x;

	while (mov < N){

		if (U0[mov] <= 0){
			U0[mov] = nan("nan");
			River[mov] = nan("nan");
		}

		if ((U0[mov] > 0) || (isnan(U0[mov]) != 1)){

			CT[mov] = 1;
			River[mov] = 1;
			Pos[mov] = mov;

			//============================================================
			// Para habilitar bordas com condi��es de contorno de Newmann
			//if ((mov % DIMx == 0) || (mov % DIMx == DIMx))
			//{
			//CT[mov] = 0;
			//}
			//if ((mov / DIMx == 0) || (mov / DIMx == DIMy))
			//{
			//	CT[mov] = 0;
			//}

			// ===========================================================

		}

		mov += gridDim.x * blockDim.x;

	}

}


__global__ void ClassMatPOS(int def_med, int diffusion, int advection, float lambda, float decay, float mob, float *TDF, float *TADV, int *CT, int *Loc, float *B, \
	float *M, float *F, float *D, float *E1, float *E2, int *IDrow, int *IDcolumn, \
	float *GF_1, float *GF_2,int DIMx, int DIMy, int N,\
	int Nred, float *DFx, float *DFy, float Vx, float Vy, float *dx, float *dy, float dt){

	//Nred � o n�mero de elementos ativos
	
	int mov1 = blockDim.x*blockIdx.x + threadIdx.x;

	while (mov1 < N){
		int x = mov1 % DIMx;
		int y = mov1 / DIMx;

		if (CT[mov1] != 0){

			// TOP
			if (y > 0){
				if (CT[mov1 - DIMx] == 0){
					// encontrar posi��o do primeiro n� n�o nulo acima 
					int re = 0;
					int reCT = 0;
					int an = 0; /*0*/
					int a = 0;
					while ((reCT == 0) && (a == 0)){
						an++;
						if ((mov1 - an*DIMx) / DIMx > 0){/*>*/
							re = Loc[mov1 - an*DIMx];
							reCT = CT[mov1 - an*DIMx];
						}
						else{ a = 1; }
					}
					if (reCT != 0){


						IDcolumn[Loc[mov1]] = re;
						IDrow[Loc[mov1]] = Loc[mov1];

						if (def_med == 0){
							top(def_med, lambda, DFy, 0, 0, Vy, mob, dy, diffusion, advection, TDF, TADV, B);
						}
						else{
							
							top(def_med, lambda, DFy,IDrow[Loc[mov1]], IDcolumn[Loc[mov1]], Vy, mob, dy, diffusion, advection, TDF, TADV, B);
							//top(def_med, lambda, DFy, Loc[mov1], re, Vy, mob, dy, diffusion, advection, TDF, TADV, B);
						}

						GF_1[Loc[mov1]] = -B[0];
						GF_2[Loc[mov1]] =  B[0];
					}
					else{

						IDcolumn[Loc[mov1]] = -1;
						IDrow[Loc[mov1]] = Loc[mov1];
					}
				}
				else{

				
					IDcolumn[Loc[mov1]] = Loc[mov1] - (Loc[mov1] - Loc[mov1 - DIMx]);
					IDrow[Loc[mov1]] = Loc[mov1];

					if (def_med == 0){
						top(def_med, lambda, DFy,0, 0, Vy, mob, dy, diffusion, advection, TDF, TADV, B);
					}
					else{
						top(def_med, lambda, DFy,IDrow[Loc[mov1]], IDcolumn[Loc[mov1]], Vy, mob, dy, diffusion, advection, TDF, TADV, B);
						//top(def_med, lambda, DFy, Loc[mov1], Loc[mov1] - (Loc[mov1] - Loc[mov1 - DIMx]), Vy, mob, dy, diffusion, advection, TDF, TADV, B);
					}

					GF_1[Loc[mov1]] = -B[0];
					GF_2[Loc[mov1]] =  B[0];
				}


			}

			// BOTTOM
			//__syncthreads();
			if (y < DIMy - 1){
				if (CT[mov1 + DIMx] == 0){
					int re1 = 0;
					int reCT1 = 0;
					int an1 = 0;
					int a1 = 0;
					while ((reCT1 == 0) && (a1 == 0)){
						an1++;
						if ((mov1 + an1*DIMx) / DIMx < DIMy - 1){/*<*/
							re1 = Loc[mov1 + an1*DIMx];
							reCT1 = CT[mov1 + an1*DIMx];
						}
						else{ a1 = 1; }
					}
					if (reCT1 != 0){
						IDcolumn[Loc[mov1] + Nred] = re1;
						IDrow[Loc[mov1] + Nred] = Loc[mov1];

						if (def_med == 0){
							bottom(def_med, lambda, DFy,0,0, Vy, mob, dy, diffusion, advection, TDF, TADV, M);
						}
						else{
							bottom(def_med, lambda, DFy,IDrow[Loc[mov1] + Nred], IDcolumn[Loc[mov1] + Nred], Vy, mob, dy, diffusion, advection, TDF, TADV, M);
							//bottom(def_med, lambda, DFy, Loc[mov1], re1, Vy, mob, dy, diffusion, advection, TDF, TADV, M);
						}

						GF_1[Loc[mov1] + Nred] = -M[0];
						GF_2[Loc[mov1] + Nred] =  M[0];
					}
					else{
						IDcolumn[Loc[mov1] + Nred] = -1;
						IDrow[Loc[mov1] + Nred] = Loc[mov1];
					}
				}
				else{
					IDcolumn[Loc[mov1] + Nred] = Loc[mov1] + (Loc[mov1 + DIMx] - Loc[mov1]);
					IDrow[Loc[mov1] + Nred] = Loc[mov1];

					    if (def_med == 0){
						   bottom(def_med, lambda, DFy,0,0, Vy, mob, dy, diffusion, advection, TDF, TADV, M);
					    }
					    else{
						  bottom(def_med, lambda, DFy,IDrow[Loc[mov1] + Nred], IDcolumn[Loc[mov1] + Nred], Vy, mob, dy, diffusion, advection, TDF, TADV, M);
							//bottom(def_med, lambda, DFy, Loc[mov1], Loc[mov1] + (Loc[mov1 + DIMx] - Loc[mov1]), Vy, mob, dy, diffusion, advection, TDF, TADV, M);
					    }

					GF_1[Loc[mov1] + Nred] = -M[0];
					GF_2[Loc[mov1] + Nred] =  M[0];
				}

			}

			//RIGHT
			//__syncthreads();
			if (x < DIMx - 1){
				if (CT[mov1 + 1] == 0){
					int re2 = 0;
					int reCT2 = 0;
					int an2 = 0;
					int a2 = 0;
					while ((reCT2 == 0) && (a2 == 0)){
						an2++;
						if ((mov1 + an2) % DIMx < DIMx - 1){/*<*/
							re2 = Loc[mov1 + an2];
							reCT2 = CT[mov1 + an2];
						}
						else{ a2 = 1; }
					}
					if (reCT2 != 0){
						IDcolumn[Loc[mov1] + 2 * Nred] = Loc[mov1] + 1;
						IDrow[Loc[mov1] + 2 * Nred] = Loc[mov1];

						if (def_med == 0){
							right(def_med, lambda, DFx,0,0, Vx, mob, dx, diffusion, advection, TDF, TADV, F);
						}
						else{
							right(def_med, lambda, DFx,IDrow[Loc[mov1] + 2 * Nred], IDcolumn[Loc[mov1] + 2 * Nred], Vx, mob, dx, diffusion, advection, TDF, TADV, F);
							//right(def_med, lambda, DFx, Loc[mov1], Loc[mov1] + 1, Vx, mob, dx, diffusion, advection, TDF, TADV, F);
						}

						GF_1[Loc[mov1] + 2 * Nred] = -F[0];
						GF_2[Loc[mov1] + 2 * Nred] =  F[0];
					}
					else{
						IDcolumn[Loc[mov1] + 2 * Nred] = -1;
						IDrow[Loc[mov1] + 2 * Nred] = Loc[mov1];
					}
				}
				else{
					IDcolumn[Loc[mov1] + 2 * Nred] = Loc[mov1] + 1;
					IDrow[Loc[mov1] + 2 * Nred] = Loc[mov1];

					if (def_med == 0){
						right(def_med, lambda, DFx,0,0, Vx, mob, dx, diffusion, advection, TDF, TADV, F);
					}
					else{
						right(def_med, lambda, DFx,IDrow[Loc[mov1] + 2 * Nred], IDcolumn[Loc[mov1] + 2 * Nred], Vx, mob, dx, diffusion, advection, TDF, TADV, F);
						//right(def_med, lambda, DFx, Loc[mov1], Loc[mov1] + 1, Vx, mob, dx, diffusion, advection, TDF, TADV, F);
					}

					GF_1[Loc[mov1] + 2 * Nred] = -F[0];
					GF_2[Loc[mov1] + 2 * Nred] =  F[0];
				}

			}

			// LEFT 
			//__syncthreads();
			if (x > 0){

				if (CT[mov1 - 1] == 0){
					int re3 = 0;
					int reCT3 = 0;
					int an3 = 0;
					int a3 = 0;

					while ((reCT3 == 0) && (a3 == 0)){
						an3++;
						if ((mov1 - an3) % DIMx > 0){/*>=*/
							re3 = Loc[mov1 - an3];
							reCT3 = CT[mov1 - an3];
						}
						else{ a3 = 1; }
					}

					if (reCT3 != 0){
						IDcolumn[Loc[mov1] + 3 * Nred] = Loc[mov1] - 1;
						IDrow[Loc[mov1] + 3 * Nred] = Loc[mov1];

						if (def_med == 0){
							left(def_med, lambda, DFx,0,0, Vx, mob, dx, diffusion, advection, TDF, TADV, D);
						}
						else{
							left(def_med, lambda, DFx,IDrow[Loc[mov1] + 3 * Nred], IDcolumn[Loc[mov1] + 3 * Nred], Vx, mob, dx, diffusion, advection, TDF, TADV, D);							
						}

						GF_1[Loc[mov1] + 3 * Nred] = -D[0];
						GF_2[Loc[mov1] + 3 * Nred] =  D[0];
					}
					else{
						IDcolumn[Loc[mov1] + 3 * Nred] = -1;
						IDrow[Loc[mov1] + 3 * Nred] = Loc[mov1];
					}
				}
				else{
					IDcolumn[Loc[mov1] + 3 * Nred] = Loc[mov1] - 1;
					IDrow[Loc[mov1] + 3 * Nred] = Loc[mov1];

					if (def_med == 0){
						left(def_med, lambda, DFx,0,0, Vx, mob, dx, diffusion, advection, TDF, TADV, D);
					}
					else{
						left(def_med, lambda, DFx,IDrow[Loc[mov1] + 3 * Nred], IDcolumn[Loc[mov1] + 3 * Nred], Vx, mob, dx, diffusion, advection, TDF, TADV, D);
					}

					GF_1[Loc[mov1] + 3 * Nred] = -D[0];
					GF_2[Loc[mov1] + 3 * Nred] =  D[0];
				}
				
			}
			
						
			__syncthreads();

			//========================= Diagonais Internas =====================
			if ((IDcolumn[Loc[mov1] + 2 * Nred] == -1) && (IDcolumn[Loc[mov1] + 3 * Nred] != -1)){
				GF_1[Loc[mov1] + 3 * Nred] = 2 * GF_1[Loc[mov1] + 3 * Nred]; //D
				GF_2[Loc[mov1] + 3 * Nred] = 2 * GF_2[Loc[mov1] + 3 * Nred]; //D
			}
			if ((IDcolumn[Loc[mov1] + 2 * Nred] != -1) && (IDcolumn[Loc[mov1] + 3 * Nred] == -1)){
				GF_1[Loc[mov1] + 2 * Nred] = 2 * GF_1[Loc[mov1] + 2 * Nred]; //F
				GF_2[Loc[mov1] + 2 * Nred] = 2 * GF_2[Loc[mov1] + 2 * Nred]; //F
			}

			//========================= Diagonais Externas ====================
			if ((IDcolumn[Loc[mov1]] == -1) && (IDcolumn[Loc[mov1] + Nred] != -1)){
				GF_1[Loc[mov1] + Nred] = 2 * GF_1[Loc[mov1] + Nred]; //M
				GF_2[Loc[mov1] + Nred] = 2 * GF_2[Loc[mov1] + Nred]; //M
			}
			if ((IDcolumn[Loc[mov1]] != -1) && (IDcolumn[Loc[mov1] + Nred] == -1)){
				GF_1[Loc[mov1]] = 2 * GF_1[Loc[mov1]]; //B
				GF_2[Loc[mov1]] = 2 * GF_2[Loc[mov1]]; //B
			}
			//==================================================================

			IDrow[Loc[mov1] + 4 * Nred] = Loc[mov1];
			IDcolumn[Loc[mov1] + 4 * Nred] = Loc[mov1];

			center1(lambda, GF_2, Loc[mov1], Loc[mov1] + Nred, Loc[mov1] + 2 * Nred, Loc[mov1] + 3 * Nred, decay, dt, E1);
			GF_1[Loc[mov1] + 4 * Nred] = E1[0];
			center2(lambda, GF_2, Loc[mov1], Loc[mov1] + Nred, Loc[mov1] + 2 * Nred, Loc[mov1] + 3 * Nred, decay, dt, E2);
			GF_2[Loc[mov1] + 4 * Nred] = E2[0];

			//========================  Diagonal Principal ====================
			if ((IDcolumn[Loc[mov1] + 2 * Nred] == -1) && (IDcolumn[Loc[mov1] + 3 * Nred] == -1)){

				GF_1[Loc[mov1] + 4 * Nred] = E1[0] + (GF_1[Loc[mov1] + 3 * Nred] + GF_1[Loc[mov1] + 2 * Nred]);
				GF_2[Loc[mov1] + 4 * Nred] = E2[0] + (GF_2[Loc[mov1] + 3 * Nred] + GF_2[Loc[mov1] + 2 * Nred]);
			}

			if ((IDcolumn[Loc[mov1]] == -1) && (IDcolumn[Loc[mov1] + Nred] == -1)){
				GF_1[Loc[mov1] + 4 * Nred] = E1[0] +(GF_1[Loc[mov1]] + GF_1[Loc[mov1] + Nred]);
				GF_2[Loc[mov1] + 4 * Nred] = E2[0] +(GF_2[Loc[mov1]] + GF_2[Loc[mov1] + Nred]);
			}
			//==================================================================

		}
		mov1 += gridDim.x * blockDim.x;
	}
}

#endif