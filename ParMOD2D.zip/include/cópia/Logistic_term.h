#ifndef LOGISTC_TERM
#define LOGISTIC_TERM

//=========================
// where to perform the computation
typedef cusp::device_memory MemorySpace;
typedef cusp::host_memory MemorySpaceh;
// which floating point type to use
typedef int IndexType;
typedef double ValueType;
//===========================================

cusp::array1d<ValueType, MemorySpace> logistic_term(cusp::array1d<ValueType, MemorySpace> Mrub, \
	                       float ru,\
						   cusp::array1d<int, MemorySpace> un,\
						   cusp::array1d<ValueType, MemorySpace> diff_unb,\
						   cusp::array1d<ValueType, MemorySpace> Bb,\
						   cusp::array1d<ValueType, MemorySpace> L,\
						   cusp::array1d<ValueType, MemorySpace> x,\
						   cusp::array1d<ValueType, MemorySpace> b){
	//=====================================================================================
	//L = ru*b.(un-b);    // Termo log�stico <======================
	//=====================================================================================
	//Multiplica��o do vetro b pelo valor escalar ru: (Mrub = (ru*b)) <====================
	Mrub = x;
	cusp::blas::scal(Mrub, ru); //Mrub = ru*Mrub;
	//Definindo o vetor diferen�a entre un e b: (diff_unb = (un-b)) <======================
	cusp::blas::axpby(un, x, diff_unb, 1, -1);
	// multiplica��o elemento a elemento (z[i] = x[i] * y[i]) <============================
	cusp::blas::xmy(Mrub, diff_unb, L);
	// determina a combina��o de dois vetores (b = alpha * Bb + beta * L) <================
	cusp::blas::axpby(Bb, L, b, 1, 1);
	//=====================================================================================
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//cusp::print(b);
	//system("pause");
	return b;

}

#endif