#ifndef GPU_MATRIX_DF
#define GPU_MATRIX_DF
/*
int POS_B;
int POS_M;
int POS_F;
int POS_D;

int diffusion;
int advection;
float lambda;
float mob;
float decay;
float Vx;
float Vy;
*/

__device__ void diff_node(int def_med, int velocity_vec, float *lambda, float *DF, int loc_val, int POS_DF1, int POS_DF2, float *V, float mob, float *dh, int diffusion, int advection, float *GF_1, float *GF_2, int cadv){

	if ((diffusion == 1) && (advection == 0)){
		if (def_med == 0){
			GF_1[loc_val] = -lambda[0] * (DF[0] / (dh[0] * dh[0]));
			GF_2[loc_val] = lambda[0] * (DF[0] / (dh[0] * dh[0]));
		}
		else if (def_med == 1){
			GF_1[loc_val] = -lambda[POS_DF1] * ((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0];
			GF_2[loc_val] = lambda[POS_DF1] * ((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0];
		}
		else if (def_med == 2){
			GF_1[loc_val] = -lambda[POS_DF1] * ((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0];
			GF_2[loc_val] = lambda[POS_DF1] * ((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0];
		}
		else if (def_med == 3){
			GF_1[loc_val] = -lambda[POS_DF1] * (sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0];
			GF_2[loc_val] = lambda[POS_DF1] * (sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0];
		}
	}

	if (velocity_vec == 1){
		if ((advection == 1) && (diffusion == 0)){
			if (def_med == 0){
				GF_1[loc_val] = -lambda[0] * (cadv*V[POS_DF1] * mob / (2 * dh[0]));
				GF_2[loc_val] = lambda[0] * (cadv*V[POS_DF1] * mob / (2 * dh[0]));
			}
			else{
				GF_1[loc_val] = -lambda[POS_DF1] * (cadv*V[POS_DF1] * mob / (2 * dh[0]));
				GF_2[loc_val] = lambda[POS_DF1] * (cadv*V[POS_DF1] * mob / (2 * dh[0]));
			}
		}

		if ((diffusion == 1) && (advection == 1)){
			if (def_med == 0){
				GF_1[loc_val] = -lambda[0] * (DF[0] / (dh[0] * dh[0]) + (cadv*V[POS_DF1] * mob / (2 * dh[0])));
				GF_2[loc_val] = lambda[0] * (DF[0] / (dh[0] * dh[0]) + (cadv*V[POS_DF1] * mob / (2 * dh[0])));
			}
			else if (def_med == 1){
				GF_1[loc_val] = -lambda[POS_DF1] * ((((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0]) + (cadv*V[POS_DF1] * mob / (2 * dh[0])));
				GF_2[loc_val] = lambda[POS_DF1] * ((((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0]) + (cadv*V[POS_DF1] * mob / (2 * dh[0])));
			}
			else if (def_med == 2){
				GF_1[loc_val] = -lambda[POS_DF1] * ((((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0]) + (cadv*V[POS_DF1] * mob / (2 * dh[0])));
				GF_2[loc_val] = lambda[POS_DF1] * ((((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0]) + (cadv*V[POS_DF1] * mob / (2 * dh[0])));
			}
			else if (def_med == 3){
				GF_1[loc_val] = -lambda[POS_DF1] * (((sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0]) + (cadv*V[POS_DF1] * mob / (2 * dh[0])));
				GF_2[loc_val] = lambda[POS_DF1] * (((sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0]) + (cadv*V[POS_DF1] * mob / (2 * dh[0])));
			}
		}
	}

	else{

		if ((advection == 1) && (diffusion == 0)){
			if (def_med == 0){
				GF_1[loc_val] = -lambda[0] * (cadv*V[0] * mob / (2 * dh[0]));
				GF_2[loc_val] = lambda[0] * (cadv*V[0] * mob / (2 * dh[0]));
			}
			else{
				GF_1[loc_val] = -lambda[POS_DF1] * (cadv*V[0] * mob / (2 * dh[0]));
				GF_2[loc_val] = lambda[POS_DF1] * (cadv*V[0] * mob / (2 * dh[0]));
			}
		}

		if ((diffusion == 1) && (advection == 1)){
			if (def_med == 0){
				GF_1[loc_val] = -lambda[0] * (DF[0] / (dh[0] * dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
				GF_2[loc_val] = lambda[0] * (DF[0] / (dh[0] * dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
			}
			else if (def_med == 1){
				GF_1[loc_val] = -lambda[POS_DF1] * ((((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
				GF_2[loc_val] = lambda[POS_DF1] * ((((DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0]) / (2 * dh[0] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
			}
			else if (def_med == 2){
				GF_1[loc_val] = -lambda[POS_DF1] * ((((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
				GF_2[loc_val] = lambda[POS_DF1] * ((((2 * DF[POS_DF1] * DF[POS_DF2]) / (DF[POS_DF1] * dh[0] + DF[POS_DF2] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
			}
			else if (def_med == 3){
				GF_1[loc_val] = -lambda[POS_DF1] * (((sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
				GF_2[loc_val] = lambda[POS_DF1] * (((sqrt(DF[POS_DF1] * DF[POS_DF2]) / sqrt(dh[0] * dh[0])) / dh[0]) + (cadv*V[0] * mob / (2 * dh[0])));
			}
		}

	}
	//===============================================

}

__device__ void center(float *lambda, float *GF_1, float *GF_2, int loc_val, int POS_B, int POS_M, int POS_F, int POS_D, float decay, float dt){
	GF_1[loc_val] = (1 / dt) - (GF_1[POS_B] + GF_1[POS_M] + GF_1[POS_F] + GF_1[POS_D] - lambda[POS_B]*decay);//E1[0];
	GF_2[loc_val] = (1 / dt) - (GF_2[POS_B] + GF_2[POS_M] + GF_2[POS_F] + GF_2[POS_D] + lambda[POS_B]*decay);//E2[0];
}

/*
__global__ void gerMatLoc(float *U0, int *CT, int *River, int *Pos, int N, int DIMx, int DIMy){

	int mov = blockDim.x*blockIdx.x + threadIdx.x;

	while (mov < N){

		if (U0[mov] <= 0){
			U0[mov] = nan("nan");
			River[mov] = nan("nan");
		}

		if ((U0[mov] > 0) || (isnan(U0[mov]) != 1)){

			CT[mov] = 1;
			River[mov] = 1;
			Pos[mov] = mov;

		}

		mov += gridDim.x * blockDim.x;

	}

}
*/


__global__ void ClassMatPOS(int def_med, int velocity_vec, int diffusion, int advection, float *lambda, float decay, float mob, int *CT, int *Loc, \
	int *IDrow, int *IDcolumn, float *GF_1, float *GF_2, int DIMx, int DIMy, int N, \
	int Nval, float *DFx, float *DFy, float *Vx, float *Vy, float *dx, float *dy, float dt){
	
	//Nval � o n�mero de elementos ativos

	int mov1 = blockDim.x*blockIdx.x + threadIdx.x;

	while (mov1 < N){
		int x = mov1 % DIMx;
		int y = mov1 / DIMx;

		if (CT[mov1] != 0){

			// TOP
			if (y > 0){
				if (CT[mov1 - DIMx] == 0){
					// encontrar posi��o do primeiro n� n�o nulo acima 
					int re = 0;
					int reCT = 0;
					int an = 0; /*0*/
					int a = 0;
					while ((reCT == 0) && (a == 0)){
						an++;
						if ((mov1 - an*DIMx) / DIMx > 0){/*>*/
							re = Loc[mov1 - an*DIMx];
							reCT = CT[mov1 - an*DIMx];
						}
						else{ a = 1; }
					}
					if (reCT != 0){


						IDcolumn[Loc[mov1]] = -1;// re;
						IDrow[Loc[mov1]] = Loc[mov1];

					//	diff_node(def_med, lambda, DFy, Loc[mov1], Loc[mov1], re, Vy, mob, dy, diffusion, advection, GF_1, GF_2,-1);

					}
					else{

						IDcolumn[Loc[mov1]] = -1;
						IDrow[Loc[mov1]] = Loc[mov1];
					}
				}
				else{

					IDcolumn[Loc[mov1]] = Loc[mov1] - (Loc[mov1] - Loc[mov1 - DIMx]);
					IDrow[Loc[mov1]] = Loc[mov1];
		
					diff_node(def_med, lambda, DFy, Loc[mov1], Loc[mov1], Loc[mov1] - (Loc[mov1] - Loc[mov1 - DIMx]), Vy, mob, dy, diffusion, advection, GF_1, GF_2,-1); //-Vy

				}

			}

			// BOTTOM
			//__syncthreads();
			if (y < DIMy - 1){
				if (CT[mov1 + DIMx] == 0){
					int re1 = 0;
					int reCT1 = 0;
					int an1 = 0;
					int a1 = 0;
					while ((reCT1 == 0) && (a1 == 0)){
						an1++;
						if ((mov1 + an1*DIMx) / DIMx < DIMy - 1){/*<*/
							re1 = Loc[mov1 + an1*DIMx];
							reCT1 = CT[mov1 + an1*DIMx];
						}
						else{ a1 = 1; }
					}
					if (reCT1 != 0){
						IDcolumn[Loc[mov1] + Nval] = -1;// re1;
						IDrow[Loc[mov1] + Nval] = Loc[mov1];

						//diff_node(def_med, lambda, DFy, Loc[mov1] + Nval, Loc[mov1], re1, Vy, mob, dy, diffusion, advection, GF_1, GF_2,1);

					}
					else{
						IDcolumn[Loc[mov1] + Nval] = -1;
						IDrow[Loc[mov1] + Nval] = Loc[mov1];
					}
				}
				else{
					IDcolumn[Loc[mov1] + Nval] = Loc[mov1] + (Loc[mov1 + DIMx] - Loc[mov1]);
					IDrow[Loc[mov1] + Nval] = Loc[mov1];

					diff_node(def_med, lambda, DFy, Loc[mov1] + Nval, Loc[mov1], Loc[mov1] + (Loc[mov1 + DIMx] - Loc[mov1]), Vy, mob, dy, diffusion, advection, GF_1, GF_2,1);

				}

			}

			//RIGHT
			//__syncthreads();
			if (x < DIMx - 1){
				if (CT[mov1 + 1] == 0){
					int re2 = 0;
					int reCT2 = 0;
					int an2 = 0;
					int a2 = 0;
					while ((reCT2 == 0) && (a2 == 0)){
						an2++;
						if ((mov1 + an2) % DIMx < DIMx - 1){/*<*/
							re2 = Loc[mov1 + an2];
							reCT2 = CT[mov1 + an2];
						}
						else{ a2 = 1; }
					}
					if (reCT2 != 0){
						IDcolumn[Loc[mov1] + 2 * Nval] = -1;// Loc[mov1] + 1;
						IDrow[Loc[mov1] + 2 * Nval] = Loc[mov1];

					//	diff_node(def_med, lambda, DFx, Loc[mov1] + 2 * Nval, Loc[mov1], Loc[mov1] + 1, Vx, mob, dx, diffusion, advection, GF_1, GF_2,1);

					}
					else{
						IDcolumn[Loc[mov1] + 2 * Nval] = -1;
						IDrow[Loc[mov1] + 2 * Nval] = Loc[mov1];
					}
				}
				else{
					IDcolumn[Loc[mov1] + 2 * Nval] = Loc[mov1] + 1;
					IDrow[Loc[mov1] + 2 * Nval] = Loc[mov1];
				
					diff_node(def_med, lambda, DFx, Loc[mov1] + 2 * Nval, Loc[mov1], Loc[mov1] + 1, Vx, mob, dx, diffusion, advection, GF_1, GF_2,1);

				}

			}

			// LEFT 
			//__syncthreads();
			if (x > 0){

				if (CT[mov1 - 1] == 0){
					int re3 = 0;
					int reCT3 = 0;
					int an3 = 0;
					int a3 = 0;

					while ((reCT3 == 0) && (a3 == 0)){
						an3++;
						if ((mov1 - an3) % DIMx > 0){/*>=*/
							re3 = Loc[mov1 - an3];
							reCT3 = CT[mov1 - an3];
						}
						else{ a3 = 1; }
					}

					if (reCT3 != 0){
						IDcolumn[Loc[mov1] + 3 * Nval] = -1;// Loc[mov1] - 1;
						IDrow[Loc[mov1] + 3 * Nval] = Loc[mov1];

					//	diff_node(def_med, lambda, DFx, Loc[mov1] + 3 * Nval, Loc[mov1], Loc[mov1] - 1, Vx, mob, dx, diffusion, advection, GF_1, GF_2,-1);

					}
					else{
						IDcolumn[Loc[mov1] + 3 * Nval] = -1;
						IDrow[Loc[mov1] + 3 * Nval] = Loc[mov1];
					}
				}
				else{
					IDcolumn[Loc[mov1] + 3 * Nval] = Loc[mov1] - 1;
					IDrow[Loc[mov1] + 3 * Nval] = Loc[mov1];

					diff_node(def_med, lambda, DFx, Loc[mov1] + 3 * Nval, Loc[mov1], Loc[mov1] - 1, Vx, mob, dx, diffusion, advection, GF_1, GF_2,-1);
					
				}

			}
		
			//__syncthreads();

			
			//========================= Diagonais Internas =====================
			if ((IDcolumn[Loc[mov1] + 2 * Nval] == -1) && (IDcolumn[Loc[mov1] + 3 * Nval] != -1)){
				GF_1[Loc[mov1] + 3 * Nval] =  2 * GF_1[Loc[mov1] + 3 * Nval]; //D
				GF_2[Loc[mov1] + 3 * Nval] =  2 * GF_2[Loc[mov1] + 3 * Nval]; //D
			}
			if ((IDcolumn[Loc[mov1] + 2 * Nval] != -1) && (IDcolumn[Loc[mov1] + 3 * Nval] == -1)){
				GF_1[Loc[mov1] + 2 * Nval] =  2 * GF_1[Loc[mov1] + 2 * Nval]; //F
				GF_2[Loc[mov1] + 2 * Nval] =  2 * GF_2[Loc[mov1] + 2 * Nval]; //F
			}

			//========================= Diagonais Externas ====================
			if ((IDcolumn[Loc[mov1]] == -1) && (IDcolumn[Loc[mov1] + Nval] != -1)){
				GF_1[Loc[mov1] + Nval] =  2 * GF_1[Loc[mov1] + Nval]; //M
				GF_2[Loc[mov1] + Nval] =  2 * GF_2[Loc[mov1] + Nval]; //M
			}
			if ((IDcolumn[Loc[mov1]] != -1) && (IDcolumn[Loc[mov1] + Nval] == -1)){
				GF_1[Loc[mov1]] =  2 * GF_1[Loc[mov1]]; //B
				GF_2[Loc[mov1]] =  2 * GF_2[Loc[mov1]]; //B
			}
			//==================================================================
			//========================  Diagonal Principal ====================
			

			IDrow[Loc[mov1] + 4 * Nval] = Loc[mov1];
			IDcolumn[Loc[mov1] + 4 * Nval] = Loc[mov1];
			
			center(lambda, GF_1, GF_2, Loc[mov1] + 4 * Nval, Loc[mov1], Loc[mov1] + Nval, Loc[mov1] + 2 * Nval, Loc[mov1] + 3 * Nval, decay, dt);

			
			if ((IDcolumn[Loc[mov1] + 2 * Nval] == -1) && (IDcolumn[Loc[mov1] + 3 * Nval] == -1)){
				GF_1[Loc[mov1] + 4 * Nval] = GF_1[Loc[mov1] + 4 * Nval] - (GF_1[Loc[mov1] + 3 * Nval] + GF_1[Loc[mov1] + 2 * Nval]);
				GF_2[Loc[mov1] + 4 * Nval] = GF_2[Loc[mov1] + 4 * Nval] - (GF_2[Loc[mov1] + 3 * Nval] + GF_2[Loc[mov1] + 2 * Nval]);				
			}

			if ((IDcolumn[Loc[mov1]] == -1) && (IDcolumn[Loc[mov1] + Nval] == -1)){
				GF_1[Loc[mov1] + 4 * Nval] = GF_1[Loc[mov1] + 4 * Nval] - (GF_1[Loc[mov1]] + GF_1[Loc[mov1] + Nval]);
				GF_2[Loc[mov1] + 4 * Nval] = GF_2[Loc[mov1] + 4 * Nval] - (GF_2[Loc[mov1]] + GF_2[Loc[mov1] + Nval]);				
			}
			
			/*
			//======			
			if ((IDcolumn[Loc[mov1] + 2 * Nval] == -1) && (IDcolumn[Loc[mov1] + 3 * Nval] == -1) && (IDcolumn[Loc[mov1]] == -1)){			
				GF_1[Loc[mov1] + 4 * Nval] = GF_1[Loc[mov1] + 4 * Nval] - (GF_1[Loc[mov1] + 3 * Nval] + GF_1[Loc[mov1] + 2 * Nval] + GF_1[Loc[mov1]]);
				GF_2[Loc[mov1] + 4 * Nval] = GF_2[Loc[mov1] + 4 * Nval] - (GF_2[Loc[mov1] + 3 * Nval] + GF_2[Loc[mov1] + 2 * Nval] + GF_2[Loc[mov1]]);			
			}

			if ((IDcolumn[Loc[mov1] + 2 * Nval] == -1) && (IDcolumn[Loc[mov1] + 3 * Nval] == -1) && (IDcolumn[Loc[mov1] + Nval] == -1)){
				GF_1[Loc[mov1] + 4 * Nval] = GF_1[Loc[mov1] + 4 * Nval] - (GF_1[Loc[mov1] + 3 * Nval] + GF_1[Loc[mov1] + 2 * Nval] + GF_1[Loc[mov1] + Nval]);
				GF_2[Loc[mov1] + 4 * Nval] = GF_2[Loc[mov1] + 4 * Nval] - (GF_2[Loc[mov1] + 3 * Nval] + GF_2[Loc[mov1] + 2 * Nval] + GF_2[Loc[mov1] + Nval]);
			}

			if ((IDcolumn[Loc[mov1]] == -1) && (IDcolumn[Loc[mov1] + Nval] == -1) && (IDcolumn[Loc[mov1] + 2 * Nval] == -1)){			
				GF_1[Loc[mov1] + 4 * Nval] = GF_1[Loc[mov1] + 4 * Nval] - (GF_1[Loc[mov1]] + GF_1[Loc[mov1] + Nval] + GF_1[Loc[mov1] + 2 * Nval]);
				GF_2[Loc[mov1] + 4 * Nval] = GF_2[Loc[mov1] + 4 * Nval] - (GF_2[Loc[mov1]] + GF_2[Loc[mov1] + Nval] + GF_2[Loc[mov1] + 2 * Nval]);
			}

			if ((IDcolumn[Loc[mov1]] == -1) && (IDcolumn[Loc[mov1] + Nval] == -1) && (IDcolumn[Loc[mov1] + 3 * Nval] == -1)){
				GF_1[Loc[mov1] + 4 * Nval] = GF_1[Loc[mov1] + 4 * Nval] - (GF_1[Loc[mov1]] + GF_1[Loc[mov1] + Nval] + GF_1[Loc[mov1] + 3 * Nval]);
				GF_2[Loc[mov1] + 4 * Nval] = GF_2[Loc[mov1] + 4 * Nval] - (GF_2[Loc[mov1]] + GF_2[Loc[mov1] + Nval] + GF_2[Loc[mov1] + 3 * Nval]);
			}			
			//==================================================================
			*/

		}
		mov1 += gridDim.x * blockDim.x;
	}
}

#endif